module.exports = {
  /**
    * define actions for the page object
  */

  /**
   * define assertions for the page object
   */
}