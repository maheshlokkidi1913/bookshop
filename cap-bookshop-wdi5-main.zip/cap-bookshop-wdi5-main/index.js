const { AdminService } = require('./srv/admin-service')
module.exports = { AdminService }
