sap.ui.define(["sap/ui/core/mvc/Controller"],o=>{"use strict";return o.extend("com.bookshop.bookshopproject.controller.App",{onInit(){}})});
//# sourceMappingURL=App.controller.js.map